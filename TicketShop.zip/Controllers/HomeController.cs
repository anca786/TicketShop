using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TicketShop.Models;
using TicketShop.Data;
using Microsoft.AspNetCore.Identity; // AICI: Necesar pentru User Manager

namespace TicketShop.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly ApplicationDBContext _context;
    // AICI: Ad�ug�m UserManager pentru a ?ti cine e logat
    private readonly UserManager<ApplicationUser> _userManager;

    // AICI: Actualiz�m constructorul s� primeasc� ?i userManager
    public HomeController(ILogger<HomeController> logger, ApplicationDBContext context, UserManager<ApplicationUser> userManager)
    {
        _logger = logger;
        _context = context;
        _userManager = userManager;
    }

    public async Task<IActionResult> Index(string cautare)
{
    // 1. Pornim cu toate evenimentele (dar nu le aducem �nc� din baz�)
    var query = _context.Evenimente
        .Include(e => e.Categorie)
        .Where(e => e.Status == EventStatus.Approved) 
        .AsQueryable();

    // 2. Aplic�m filtrul DOAR dac� utilizatorul a scris ceva
    if (!string.IsNullOrEmpty(cautare))
    {
        query = query.Where(e => e.Nume.Contains(cautare) || 
                                 e.Descriere.Contains(cautare) || 
                                 e.Locatie.Contains(cautare));
    }

    query = query.Where(e => e.Data >= DateTime.Now);
    // 3. Ordon�m rezultatele (cele mai noi primele)
    query = query.OrderBy(e => e.Data);

    // Salv�m ce a c�utat userul ca s�-i r�m�n� scris �n c�su?� dup� refresh
    ViewData["CautareCurenta"] = cautare;

    // 4. Execut�m interogarea ?i trimitem lista
    return View(await query.ToListAsync());
}

    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();

        var eveniment = await _context.Evenimente
            .Include(e => e.Categorie)
            .FirstOrDefaultAsync(m => m.Id == id);

        if (eveniment == null) return NotFound();

        // 1. COD VECHI: Num�r�m biletele disponibile (Stoc)
        int bileteDisponibile = await _context.Bilete
            .CountAsync(b => b.EvenimentId == id && !b.Vandut && b.CosId == null);

        ViewBag.Stoc = bileteDisponibile;


        // 2. COD NOU: Verific�m Wishlist-ul (Inimioara)
        bool isWishlisted = false;

        // Verific�m doar dac� userul este logat
        if (User.Identity.IsAuthenticated)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null)
            {
                // C�ut�m �n baza de date wishlist-ul userului
                var wishlist = await _context.Wishlists
                    .Include(w => w.Evenimente)
                    .FirstOrDefaultAsync(w => w.UtilizatorId == user.Id);

                // Dac� are wishlist ?i evenimentul e �n el -> TRUE
                if (wishlist != null && wishlist.Evenimente.Any(e => e.Id == id))
                {
                    isWishlisted = true;
                }
            }
        }

        // Trimitem rezultatul (true/false) �n View ca s� ?tim dac� color�m inima
        ViewBag.IsWishlisted = isWishlisted;
        // ---------------------------------------------------------

        return RedirectToAction("Details", "Evenimente", new { id = id });
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    public IActionResult Despre()
    {
        return View();
    }

    public IActionResult Contact()
    {
        return View();
    }

    public IActionResult FAQ()
    {
        return View();
    }
}